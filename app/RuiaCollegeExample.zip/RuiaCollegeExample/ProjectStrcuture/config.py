# config.py

# Enable Flask's debugging features. Should be False in production
DEBUG = True

SECRET_KEY = 'hard to guess string'
