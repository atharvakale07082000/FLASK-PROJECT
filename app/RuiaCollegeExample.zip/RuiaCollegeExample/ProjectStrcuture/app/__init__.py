# app/__init__.py

from flask import Flask
from flask.ext.bootstrap import Bootstrap

# Initialize the app


# Load the views


# Load the config file


