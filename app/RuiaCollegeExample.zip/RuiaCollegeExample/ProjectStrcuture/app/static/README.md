This directory has static files (image, javascript and css files, for example) for the application.
